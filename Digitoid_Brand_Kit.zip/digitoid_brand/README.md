# Digitoid Brand Kit — implementation draft

## Included
- Editable SVG robot icon in transparent, light, dark and red backgrounds.
- PNG exports (16/32/48/180/192/512 as applicable) and favicon.ico.
- SVG wordmarks for light and dark UI (text remains editable and uses installed fallback font).
- tokens.css and tokens.json for web implementation.
- preview.html for visual inspection.

## Implementation
1. Use `icon.svg` as a transparent standalone mark; `icon-light-192.png` for PWA and `favicon.ico` for browsers.
2. Use `wordmark-light.svg` on light backgrounds, `wordmark-dark.svg` on dark backgrounds.
3. Import `tokens.css` into the web application, then map existing UI components to these variables.
4. For production, convert the wordmark lettering to paths in your vector design tool after choosing and licensing the approved font.

## Fonts
Proposed practical defaults: **Inter** for English, **Noto Sans Arabic** for Arabic, system monospace for code. Font binaries are deliberately **not included**. Obtain approved font files separately and confirm licenses. The exact Boubyan website typeface could not be verified.

## Boubyan co-branding
The official Boubyan mark is **not bundled** or redrawn. Download approved artwork and rules from https://www.bankboubyan.com/en/bank-boubyan-branding-kit and add it separately as a secondary endorsement, with its own spacing and proportions. Do not treat the AI-generated reference mockup as official brand artwork.

## Status
This is a custom vector implementation of the approved **minimal robot direction**, not a pixel-perfect vectorization of the generated concept. Inspect and approve before production use. Palette values are proposed Digitoid values, not verified official Boubyan specifications.
