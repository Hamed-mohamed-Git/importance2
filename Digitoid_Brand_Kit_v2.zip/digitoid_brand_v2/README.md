# Digitoid brand kit v2 — source-faithful revision

## What changed
The previous kit used a simplified SVG drawing that did NOT match the approved robot. This version uses a direct raster crop from the **approved polished concept board** (`a_clean_polished_modern_brand_presentation_board.png`), rather than inventing a new robot geometry.

## Assets
- `approved-robot-source-crop.png`: exact pixels cropped from the approved concept board, including its original background.
- `icon-*.png`, `favicon.ico`: resampled icon assets from that crop, on white backgrounds.
- `approved-robot-raster-wrapper.svg`: SVG *container* embedding the original raster crop. **Not a true vector logo**.
- `tokens.css` and `tokens.json`: proposed Digitoid UI colors and fallback font stacks.

## Limitations / next steps
The approved concept is a raster image within a design board. A genuine transparent-background, scalable vector logo with precisely matching curves cannot be guaranteed from this image alone. These exports retain some original background and may be less crisp at 16px. For production, have a designer trace the approved mascot and review the result against the source, or supply an original vector asset. Do not use the earlier `icon.svg` as it is a different drawing.

The official Boubyan logo and licensed Boubyan font are NOT bundled. Obtain approved originals from your brand team. Inter and Noto Sans Arabic are font *recommendations*, not packaged fonts.
