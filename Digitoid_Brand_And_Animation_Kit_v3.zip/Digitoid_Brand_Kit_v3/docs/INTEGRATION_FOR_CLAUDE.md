# Claude implementation handoff — Digitoid v3

## Critical fidelity policy
- `assets/master/approved-robot-source.png` is a pixel-for-pixel copy of the approved raster crop from Concept 2. It is **not transparent** and **not vector**.
- Animated assets are **derived variants**: eye pixels were modified. They are NOT exact official source artwork. Review them visually before production.
- Do not use the older geometric SVG (`digitoid_brand/icon.svg`) or invent new robot geometry.
- Never claim the raster-wrapper SVG is an editable vector.
- The brand presentation's Boubyan logo is AI-generated and is **not** an approved official bank logo. No Boubyan logo or licensed font is bundled.

## Integration
1. Copy `assets/` into an appropriate public directory, e.g. `public/digitoid/assets/`.
2. Import `tokens.css` and `src/robot-status.css` (merge with existing tokens, do not overwrite blindly).
3. For React/TSX, copy `src/RobotStatus.tsx` and render `<RobotStatus state="working" detail="Comparing Figma with requirements" />`.
4. For plain JS, import `setRobotStatus` from `src/robot-status.js`; invoke it only when state changes. Ensure the CSS is loaded.
5. Map **actual** host/workflow states to the six robot states. Never use timers to fake progress or readiness.
6. Keep the sidebar logo static (`assets/master/approved-robot-source.png` or small static icon); animated robot appears only in the review work area and meaningful states.
7. Use plain text status next to the robot; animation alone is not accessible status communication.
8. Support reduced motion and page visibility. React component handles this; vanilla JS caller must rerender on changes.
9. GIFs can be CPU-inefficient; if deployment requires more performance, replace with a vetted layered SVG/Lottie master once available.

## Suggested state mapping
- idle: no task active
- thinking: reasoning / analyzing input
- working: running an identified workflow stage
- needs-input: paused for developer or team response
- completed: host-confirmed complete AND plan actually ready
- failed: host-confirmed failure, with clear recovery instructions

## Validation gates
- Compare `assets/master/approved-robot-source.png` against the approved board.
- Review each derivative animation at 1x and 2x; no halo/eye artifacts.
- Check 16/32/64/180/512 icons for readability.
- Check light background and dark background: raster has white background and must appear in a white tile on dark UI; do not pretend it is transparent.
- Obtain a true layered transparent master for production-perfect animation, and official Boubyan co-brand assets.
- Confirm no animation in sidebar, and no flashing, aggressive motion, or autoplay video.
