import React, { useEffect, useState } from 'react';
import './robot-status.css';
export type RobotState = 'idle'|'thinking'|'working'|'needs-input'|'completed'|'failed';
const LABEL: Record<RobotState,string> = {
 idle:'Ready', thinking:'Thinking', working:'Working',
 'needs-input':'Needs your input', completed:'Completed', failed:'Unable to continue'
};
/** Set assetBase to the public URL containing the assets/animations folder. */
export function RobotStatus({state,detail,assetBase='/digitoid/assets/animations',size=64}:
 {state:RobotState;detail?:string;assetBase?:string;size?:number}) {
 const [reduce,setReduce]=useState(false);
 const [visible,setVisible]=useState(typeof document==='undefined'?true:!document.hidden);
 useEffect(()=>{
  const mq=window.matchMedia('(prefers-reduced-motion: reduce)');
  const onChange=()=>setReduce(mq.matches); const onVis=()=>setVisible(!document.hidden);
  onChange();mq.addEventListener('change',onChange);document.addEventListener('visibilitychange',onVis);
  return()=>{mq.removeEventListener('change',onChange);document.removeEventListener('visibilitychange',onVis)};
 },[]);
 const animated=visible&&!reduce&&['idle','thinking','working'].includes(state);
 const src=`${assetBase}/${state}.${animated?'gif':'png'}`;
 return <div className="dg-robot" data-state={state} style={{'--dg-robot-size':`${size}px`} as React.CSSProperties} role="status" aria-live={state==='failed'?'assertive':'polite'}>
   <img className="dg-robot__image" src={src} alt="" aria-hidden="true" />
   <div className="dg-robot__text"><div className="dg-robot__status"><span className="dg-robot__indicator" aria-hidden="true"/>{LABEL[state]}</div>{detail&&<div className="dg-robot__detail">{detail}</div>}</div>
 </div>;
}
