/** Vanilla JS version. Use setRobotStatus(root, state, detail, assetBase). */
export const STATES=['idle','thinking','working','needs-input','completed','failed'];
const LABEL={'idle':'Ready','thinking':'Thinking','working':'Working','needs-input':'Needs your input','completed':'Completed','failed':'Unable to continue'};
export function setRobotStatus(root,state,detail='',assetBase='/digitoid/assets/animations'){
 if(!STATES.includes(state))throw Error('Unknown robot state');
 root.classList.add('dg-robot');root.dataset.state=state;root.setAttribute('role','status');
 root.setAttribute('aria-live',state==='failed'?'assertive':'polite');
 const mq=matchMedia('(prefers-reduced-motion: reduce)');
 const animated=!document.hidden&&!mq.matches&&['idle','thinking','working'].includes(state);
 const img=document.createElement('img');img.className='dg-robot__image';img.alt='';img.setAttribute('aria-hidden','true');img.src=`${assetBase}/${state}.${animated?'gif':'png'}`;
 const txt=document.createElement('div');txt.className='dg-robot__text';
 const title=document.createElement('div');title.className='dg-robot__status';title.textContent=LABEL[state];
 const dot=document.createElement('span');dot.className='dg-robot__indicator';dot.setAttribute('aria-hidden','true');title.prepend(dot);txt.append(title);
 if(detail){const p=document.createElement('div');p.className='dg-robot__detail';p.textContent=detail;txt.append(p)}
 root.replaceChildren(img,txt);
}
// Caller should re-render on visibilitychange and reduced-motion changes, or use the React component.
