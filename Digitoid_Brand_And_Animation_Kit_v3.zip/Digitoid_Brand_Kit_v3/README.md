# Digitoid Brand & Motion Kit v3

**Reference:** Approved Concept 2 robot from the earlier polished presentation.

## Contents
- `assets/master/approved-robot-source.png` — exact original raster crop (225×211, white background).
- `assets/icons/` — white-background PNG icons (16–512) and favicon.
- `assets/animations/` — 6 GIF motion states, matching PNG static fallbacks and PNG spritesheets.
- `src/RobotStatus.tsx` — React status component with reduced-motion/visibility handling.
- `src/robot-status.js` — vanilla JavaScript helper.
- `src/robot-status.css` — component styles.
- `tokens.css`, `tokens.json` — proposed Digitoid design tokens and font stacks.
- `demo/index.html` — browser preview of states.
- `docs/INTEGRATION_FOR_CLAUDE.md` — implementation checklist.

## Important limitations
This is a raster-based brand kit, not an exact editable vector. The static robot reference preserves approved pixels; animated eye treatments are reconstructed over those pixels and require visual approval. The original background is white, not transparent. The bank's official logo and proprietary font are NOT included. Do not treat AI-generated bank branding in the concept board as official. Use an official approved asset provided by Boubyan.

For a fully production-ready, perfectly faithful animated vector identity, obtain the layered original or commission a manual vector recreation approved against the reference.
